package com;

public class rating_adapter {
}
